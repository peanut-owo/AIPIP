import docx
import os
import random
from random import sample
import xlsxwriter as xw


work_path = './输出'
os.chdir(work_path)

pingyuku = "尊敬师长,勤学好问,听课认真，课堂情绪饱满,遵守教学管理制度,出勤率高，课堂秩序好,自学能力较好，能做到课前预习,课后复习," \
           "学生全员全程参与学习,积极参与课堂教学活动,思维活跃，踊跃发言,学习气氛活跃,思考有条理，有自己想法和创新," \
           "课后常和老师交流，主动提问,积极参加辅导答疑,有良好学习习惯,较好地掌握本门课程基本知识、基本理论和基本技能" \
           "活学活用，可运用已学知识提出、分析、解决实际问题"
pingyulist = pingyuku.split(",")

f = open('课表.txt', encoding='utf-8')
xinxi = f.readlines()
f.close()

workbook = xw.Workbook('汇总.xlsx')  # 创建工作簿
worksheet1 = workbook.add_worksheet("sheet1")  # 创建子表
worksheet1.activate()  # 激活表
title = ['序号', '年级', '班级', '任课教师姓名', '合计得分']  # 设置表头
worksheet1.write_row('A1', title)  # 从A1单元格开始写入表头# 从第二行开始写入数据

#print(xinxi)
count = 1
for line in xinxi:
	list1 = line.split("\t")
	#print(list1)
	t = True
	list2 = []
	while t:
		list2 = [random.randint(7, 10) for i in range(10)]
		if sum(list2) >= 83 and sum(list2) <= 99:
			t = False
	
	pingyu = sample(pingyulist, 8)
	pingyustr = "，".join(pingyu[2:])
	
	j = 0
	doc = docx.Document('教师评学表.docx')  # Document 对象
	table1 = doc.tables[0]
	# print(table1)
	# for row in table1.rows:
	# 	print(j,"--------------------------------")
	# 	j+=1
	# 	i=0
	# 	for cell in row.cells:
	# 		print(i)
	# 		i+=1
	# 		print(cell.text)
	
	table1.cell(1, 2).text = "智能与电气电子工程学院"
	table1.cell(1, 5).text = list1[0]
	table1.cell(2, 1).text = list1[5]
	table1.cell(2, 3).text = list1[4] + "班"
	table1.cell(2, 5).text = list1[7][0:2]
	
	table1.cell(4, 5).text = str(list2[0])
	table1.cell(5, 5).text = str(list2[1])
	table1.cell(6, 5).text = str(list2[2])
	table1.cell(7, 5).text = str(list2[3])
	table1.cell(8, 5).text = str(list2[4])
	table1.cell(9, 5).text = str(list2[5])
	table1.cell(10, 5).text = str(list2[6])
	table1.cell(11, 5).text = str(list2[7])
	table1.cell(12, 5).text = str(list2[8])
	table1.cell(13, 5).text = str(list2[9])
	
	table1.cell(14, 5).text = str(sum(list2))  # 总分
	
	table1.cell(15, 1).text = "              优秀     良好     一般     差"
	table1.cell(16, 0).text = "评语及建议：\r    " + list1[4] + "的学生做到了" + pingyu[0] + "，" + \
	                          pingyu[1] + "而且" + pingyustr + "。\r\r\r" + "                                                               签字：" + list1[1] +\
								"\r" +"                                                               2022年7月6日"

	doc.save('教师评学表.docx')
	doc.save('表一：教师评学表'+list1[4]+list1[0]+'.docx')
	
	data = []
	data.append(str(count))
	data.append(str(list1[4][0:2]))
	data.append(str(list1[4]))
	data.append(str(list1[1]))
	data.append(str(sum(list2)))
	#print(data)
	
	row = 'A' + str(count+1)
	worksheet1.write_row(row, data)
	

	
	print(count,'OK:'+'表一：教师评学表'+list1[4]+list1[0]+'.docx')
	count+=1

workbook.close()  # 关闭表

# tables = [table for table in doc.tables]
# for table in tables:
#     for row in table.rows:
#         for cell in row.cells:
#             print (cell.text,end='  ')
#         print()
#     print('\n')
