from tkinter import *
from tkinter import messagebox
import tiqu


def str_to_dict(str0):
	# print(str0)
	b = str0.split("\n")
	# print(b)
	c = []
	d = {}
	for i in b:
		if i == '':
			pass
		elif "\t" in i:
			c = i.split("\t")
		elif " " in i:
			c = i.split(" ")
		else:
			pass
		# print(c)
		d[c[0]] = c[1]
	# print(d)
	return d

def str_to_list(str0):
	b = str0.split("\n")
	c = list(filter(lambda x: x != "", b))
	return c

def click_button():
	# 使用消息对话框控件，showinfo()表示温馨提示
	# messagebox.showinfo(title='温馨提示', message='欢迎')
	try:
		lujing = entry0.get()  # 路径是否输入
		if lujing == "":
			path1 = './'
		else:
			path1 = lujing
		
		op = v.get()
		if op == 1:
			tiqu.insert_rename(op, path1, content=entry1.get())
		elif op == 2:
			tiqu.insert_rename(op, path1, content=entry2.get())
		elif op == 3:
			tiqu.insert_rename(op, path1, content=entry4.get(), index=int(entry3.get()))
		elif op == 4:
			pipei0 = text1.get("1.0", END)
			pipei_dict0 = str_to_dict(pipei0)
			tiqu.insert_rename(op, path1, dict1=pipei_dict0)
		elif op == 5:
			tiqu.draw_rename(op, path1, index_f=int(entry5.get()))
		elif op == 6:
			tiqu.draw_rename(op, path1, index_l=int(entry6.get()))
		elif op == 7:
			tiqu.draw_rename(op, path1, index_p=int(entry7.get()))
		elif op == 8:
			pipei1 = text2.get("1.0", END)
			print(pipei1)
			pipei_list1 = str_to_list(pipei1)
			print(pipei_list1)
			tiqu.draw_rename(op, path1, find_list=pipei_list1)
		else:
			pass
		
		messagebox.showinfo(title='温馨提示', message="成功")
		
	except Exception as e:
		messagebox.showinfo(title='温馨提示', message=str(e))

root = Tk()
v = IntVar()
root.geometry('500x500')
root.title("modifyFN")
root.iconbitmap('Hyperion-3D-Icons.ico')
#root.config(background="#E5E1EB")

label0 = Label(root, text="路径")
label0.grid(row=0, column=1)
entry0 = Entry(root)
entry0.grid(row=0, column=2)
label1 = Label(root, text="示例：C:/jieguo/ceshi")
label1.grid(row=0, column=3)

op1 = Radiobutton(root, text='开头添加', variable=v, value=1)
op1.grid(row=1, column=1)
entry1 = Entry(root)
entry1.grid(row=1, column=2)

op2 = Radiobutton(root, text='结尾添加', variable=v, value=2)
op2.grid(row=2, column=1)
entry2 = Entry(root)
entry2.grid(row=2, column=2)

op3 = Radiobutton(root, text='指定位置添加', variable=v, value=3)
op3.grid(row=3, column=1)
entry3 = Entry(root, width=5)
entry3.grid(row=3, column=3)
entry4 = Entry(root)
entry4.grid(row=3, column=2)

op4 = Radiobutton(root, text='匹配内容添加', variable=v, value=4)
op4.grid(row=4, column=1)
text1 = Text(root, width=30, height=5, undo=True, autoseparators=False)
text1.grid(row=4, column=2)
label2 = Label(root, text="示例：\n180210137	张佳\n202210106	冯博\n20210109	葛超\n200220114	寒梅",justify='left')
label2.grid(row=4, column=3)

op5 = Radiobutton(root, text='保留前几位', variable=v, value=5)
op5.grid(row=5, column=1)
entry5 = Entry(root, width=5)
entry5.grid(row=5, column=2)

op6 = Radiobutton(root, text='保留后几位', variable=v, value=6)
op6.grid(row=6, column=1)
entry6 = Entry(root, width=5)
entry6.grid(row=6, column=2)

op7 = Radiobutton(root, text='去除第几位', variable=v, value=7)
op7.grid(row=7, column=1)
entry7 = Entry(root, width=5)
entry7.grid(row=7, column=2)
label1 = Label(root, text="正数代表正数第几位\n负数代表倒数第几位")
label1.grid(row=7, column=3)

op8 = Radiobutton(root, text='匹配保留', variable=v, value=8)
op8.grid(row=8, column=1)
text2 = Text(root, width=30, height=5, undo=True, autoseparators=False)
text2.grid(row=8, column=2)
label3 = Label(root, text="示例：\n数字逻辑\n网络安全\n网页制作与网站建设\n移动软件开发实训",justify='left')
label3.grid(row=8, column=3)

button = Button(root, text="运行", width=10, command=click_button)
button.grid(row=9, column=3)

mainloop()
