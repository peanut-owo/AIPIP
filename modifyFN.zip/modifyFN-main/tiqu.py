# -*- coding: utf-8 -*-
import os
# Python根据条件修改目录里的文件名:将不想要的删去或者替换掉
# 设定文件路径
# path = './ceshi'
def insert_rename(op, path, content='', index=0, dict1=None):
	if dict1 is None:
		dict1 = {}
	
	def insert_front(str0):
		str0 = content + str0
		return str0
	
	def insert_end(str0):
		list0 = str0.split(".")
		list0[-2] += content
		list0[-2] += "."
		return ''.join(list0)
	
	def insert_index(str0, index0):
		list0 = list(str0)
		list0.insert(int(index0) - 1, content)
		str_out = ''.join(list0)
		return str_out
	
	def insert_match(dict0):
		dir_list = dict0.keys()
		for key in dir_list:
			n = filename.find(key)
			if n == -1:
				pass
			else:
				a = filename.split(".")
				a[-2] += dict0.get(key)
				a[-2] += "."
				return ''.join(a)
		return filename
	
	# 对目录下的文件进行遍历
	for filename in os.listdir(path):
		#print(filename)
		if op == 1:
			newname = insert_front(filename)
		
		elif op == 2:
			newname = insert_end(filename)
		
		elif op == 3:
			newname = insert_index(filename, index)
		
		elif op == 4:
			newname = insert_match(dict1)
		
		else:
			newname = filename
		
		os.rename(os.path.join(path, filename), os.path.join(path, newname))


def draw_rename(op, path, index_f=0, index_l=0, index_p=0, find_list=None):
	if find_list is None:
		find_list = []
	
	def draw_front(index_f0):
		a = filename.split(".")
		b = "".join(a[:-1])
		if index_f0 >= len(b):
			return b + "." + a[-1]
		else:
			return b[:index_f0] + "." + a[-1]
	
	def draw_end(index_l0):
		a = filename.split(".")
		b = "".join(a[:-1])
		if index_l0 >= len(b):
			return b + "." + a[-1]
		else:
			return b[-index_l0:] + "." + a[-1]
	
	def delete_index(index_p0):
		if index_p0 > 0:
			index_p0 -= 1
		a = filename.split(".")
		b = "".join(a[:-1])
		c = list(b)
		c.pop(index_p0)
		return "".join(c)+"."+a[-1]
	
	def draw_match(find_list0):
		for str1 in find_list0:
			n = filename.find(str1)
			if n == -1:
				pass
			else:
				a = filename.split(".")
				return str1 + "." + a[-1]
		return filename
	
	
	for filename in os.listdir(path):
		print(filename)
		# 判断是否是文件（查找以QL开头以.rmvb结尾的文件）
		# newName=file.replace("QL","")#这一句的效果是直接删除QL
		if op == 5:
			newname = draw_front(index_f)
		
		elif op == 6:
			newname = draw_end(index_l)
		
		elif op == 7:
			newname = delete_index(index_p)
		
		elif op == 8:
			newname = draw_match(find_list)
		
		else:
			newname = filename
		
		os.rename(os.path.join(path, filename), os.path.join(path, newname))


# draw_rename(7,'./ceshi',index_p=0)
# draw_rename(8, './ceshi',find_list=["计算机基础", "专业综合实训", "入侵检测技术", "软件测试", "软件工程", "数据结构"])

# insert_rename(1, './ceshi',"ff")
# insert_rename(4,'./ceshi', "f0f",dict1={'软件测试':"123456789","软件工程":"45632587","eerr":"jejer","数据结构":"456"})


