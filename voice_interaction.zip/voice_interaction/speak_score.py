import speech_recognition as sr   #pyaudio SpeechRecognition模块
from aip import AipSpeech
import pygame
import openpyxl

APP_ID = ''
API_KEY = ''
SECRET_KEY = ''
clientBaidu = AipSpeech(APP_ID, API_KEY, SECRET_KEY)


def rec(rate=16000):     #从系统麦克风拾取音频数据，采样率为 16000
    r = sr.Recognizer()
    with sr.Microphone(sample_rate=rate) as source:
        print("请说")
        audio = r.listen(source)

    with open("recording.wav", "wb") as f:
        f.write(audio.get_wav_data())
    return 1

def listen():
    with open('recording.wav', 'rb') as f:
        audio_data = f.read()

    results = clientBaidu.asr(audio_data, 'wav', 16000, {
        'dev_pid': 1537,
    })
    if 'result' in results:
        print("你的问题是：" + results['result'][0])
        return results['result'][0]
    else:
        print("出现错误，错误代码：" , results['err_no'])

def speak(text):
    result = clientBaidu.synthesis(text, 'zh', 1, {    #这里的参数可以调   zh表示中文
        'spd': 4,   #语速
        'vol': 5,   #音量
        'per': 5118,   #类型
    })
    if not isinstance(result, dict):
        with open('audio.mp3', 'wb') as f:
            f.write(result)
            f.close()

def play():
    pygame.mixer.init()
    pygame.mixer.music.load("D:/语音助手/对话助手/audio.mp3")#注意这里需要使用绝对路径
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pass
    pygame.mixer.music.unload()

def getscore(name,dialog):
    position_s = dialog.find(name)+len(name)
    position_e = dialog.find("分")
    score = dialog[position_s+1:position_e]
    if dialog[position_s] == "加":
        if score.isdigit():
            return "加",int(score)
        elif score == "五":
            return "加",5
        elif score == "十":
            return "加",10
        elif score == "十五":
            return "加",15
        elif score == "二十":
            return "加",20
        else:
            return "",0
    elif dialog[position_s]=="减":
        if score.isdigit():
            return "减",-int(score)
        elif score == "五":
            return "减",-5
        elif score == "十":
            return "减",-10
        elif score == "十五":
            return "减",-15
        elif score == "二十":
            return "减",-20
        else:
            return "",0
    else:
        return "",0

def score(filename,speak):
    workbook = openpyxl.load_workbook(filename)	# 返回一个workbook数据类型的值
    sheet = workbook['Sheet1']
    #print(workbook.sheetnames)	# 打印Excel表中的所有表
    namelist = []
    scorelist =[]
    stu_num = 0
    for cell in sheet['A']:
        if cell.value is not None:  # 检查单元格是否有内容
            stu_num += 1
    for i in range(stu_num):
        str_i = "A"+str(i+1)
        cell = sheet[str_i]
        namelist.append(cell.value)
    #print(namelist)
    for i in range(stu_num):
        str_i = "B" + str(i + 1)
        cell = sheet[str_i]
        scorelist.append(int(cell.value))
    speak_q_test = speak
    count=0
    for i in namelist:
        count+=1
        if speak_q_test.find("退出")!=-1:
            return "0"
        n = speak_q_test.find(i)
        if n!=-1 :
            score0 = getscore(i, speak_q_test)
            a = score0[0]
            b = score0[1]
            if b!=0:
                str_i = "B" + str(count)
                cell = sheet[str_i]
                score_new = int(cell.value) + b
                sheet[str_i] = str(score_new)
                text = i + a +str(b)+"分，目前总分" + str(score_new)
                rank = 1
                scorelist[count - 1] += b
                for i in scorelist:
                    if scorelist[count - 1] < i:
                        rank += 1
                print(text + "。排名班级第" + str(rank))
                workbook.save('test.xlsx')
                return text + "。排名班级第" + str(rank)
            else:
                return "我没听清楚，请再说一遍。"


        if count == stu_num:
            return "我没听清楚，请再说一遍。"

while True:
    rec()
    command = listen()
    answer = score("成绩.xlsx",command)
    speak(answer)
    play()
