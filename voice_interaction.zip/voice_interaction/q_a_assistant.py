import speech_recognition as sr   #pyaudio SpeechRecognition模块
from aip import AipSpeech
from zhipuai import ZhipuAI
import pygame

APP_ID = ''
API_KEY = ''
SECRET_KEY = ''
clientBaidu = AipSpeech(APP_ID, API_KEY, SECRET_KEY)
clientZhipu = ZhipuAI(api_key="")  # 填写您自己的APIKey


def rec(rate=16000):     #从系统麦克风拾取音频数据，采样率为 16000
    r = sr.Recognizer()
    with sr.Microphone(sample_rate=rate) as source:
        print("请说")
        audio = r.listen(source)

    with open("recording.wav", "wb") as f:
        f.write(audio.get_wav_data())
    return 1

def listen():
    with open('recording.wav', 'rb') as f:
        audio_data = f.read()

    results = clientBaidu.asr(audio_data, 'wav', 16000, {
        'dev_pid': 1537,
    })
    if 'result' in results:
        print("你的问题是：" + results['result'][0])
        return results['result'][0]
    else:
        print("出现错误，错误代码：" , results['err_no'])

def zhipu_answer(question):
    response = clientZhipu.chat.completions.create(
        model="glm-4",
        messages=[
            {"role": "user", "content": question}
        ],
    )
    answer = response.choices[0].message.content
    print(answer)
    return answer

def speak(text):
    result = clientBaidu.synthesis(text, 'zh', 1, {    #这里的参数可以调   zh表示中文
        'spd': 4,   #语速
        'vol': 5,   #音量
        'per': 5118,   #类型
    })
    if not isinstance(result, dict):
        with open('audio.mp3', 'wb') as f:
            f.write(result)
            f.close()

def play():
    pygame.mixer.init()
    pygame.mixer.music.load("D:/语音助手/对话助手/audio.mp3")#注意这里需要使用绝对路径
    pygame.mixer.music.set_volume(0.5)
    pygame.mixer.music.play()
    while pygame.mixer.music.get_busy():
        pass
    pygame.mixer.music.unload()

while True:
    rec()
    question = listen()
    answer = zhipu_answer(question)
    speak(answer)
    play()