# coding=utf-8
from selenium import webdriver
import time
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.by import By
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import threading


def click_locxy(dr, x, y, left_click=True):
    if left_click:
        ActionChains(dr).move_by_offset(x, y).click().perform()
    else:
        ActionChains(dr).move_by_offset(x, y).context_click().perform()
    ActionChains(dr).move_by_offset(-x, -y).perform()  # 将鼠标位置恢复到移动前


def move_locxy(dr, x, y):
    ActionChains(dr).move_by_offset(x, y).context_click().perform()
    ActionChains(dr).move_by_offset(-x, -y).perform()


def time_caculate(str):
    list_t = str.split(":")
    time_int = int(list_t[0]) * 60 * 60 + int(list_t[1]) * 60 + int(list_t[2])
    return time_int


browser = webdriver.Chrome()
# 转到页面
browser.get(
    "https://passport.zhihuishu.com/login?service=https://onlineservice-api.zhihuishu.com/gateway/f/v1/login/gologin")


def login(number, password):
    browser.find_element(By.ID, "lUsername").send_keys(number)
    browser.find_element(By.ID, "lPassword").send_keys(password)
    time.sleep(40)


def is_exist():
    while True:
        try:
            WebDriverWait(browser, 3600).until(
                EC.visibility_of_element_located((By.CSS_SELECTOR, ".topic-item:nth-child(1) > .item-topic"))).click()
            time.sleep(2)
            browser.find_element(By.CSS_SELECTOR, "#playTopic-dialog .el-dialog__close").click()
            time.sleep(2)
            click_locxy(browser, 500, 500)
        except:
            pass


def is_end():
    while True:
        try:
            move_locxy(browser, 500, 500)
            total_time = browser.find_element(By.XPATH,
                                              "/html/body/div[1]/div/div[2]/div[1]/div[2]/div/div/div[10]/div[4]/span[2]").text
            current_time = browser.find_element(By.XPATH,
                                                "/html/body/div[1]/div/div[2]/div[1]/div[2]/div/div/div[10]/div[4]/span[1]").text
            print(current_time,total_time)
            if total_time == current_time:
                move_locxy(browser, 500, 500)
                browser.find_element(By.ID, "nextBtn").click()
                time.sleep(1)
                click_locxy(browser, 500, 500)
            else:
                pass
            time.sleep(10)
        except:
            total_time = "00:00:00"
            current_time = "00:00:01"


if __name__=='__main__':
    login("", "")
    t1 = threading.Thread(target=is_exist)
    t2 = threading.Thread(target=is_end)
    t2.start()
    time.sleep(3)
    t1.start()
    t2.join()
    t1.join()
