import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
from sklearn.metrics import roc_auc_score
from openpyxl import load_workbook
from sklearn.model_selection import train_test_split

# 打开Excel文件
wb = load_workbook('数据.xlsx')
ws = wb.active  # 假设我们使用活动工作表
# 初始化存储前九列数据的大列表
data_lists = []
# 初始化存储第11列数据的列表
eleventh_column = []
# 遍历工作表中的每一行
for row in ws.iter_rows(1, ws.max_row):  # 从第一行到最大行
    # 取前九列数据放入列表中
    row_data = [cell.value for cell in row[:9]]
    data_lists.append(row_data)

    # 取第11列数据（注意索引从0开始）
    eleventh_column.append(row[10].value)
# 关闭工作簿
wb.close()



# 创建数据
data = torch.tensor(data_lists, dtype=torch.float32)

labels = torch.tensor(eleventh_column, dtype=torch.float32)  # 根据25%标记为1的规则

# 分割数据
# X_train, X_test = data[:40]+data[49:180], data[40:50]+data[179:]
# y_train, y_test = labels[:40]+labels[49:180], labels[40:50]+labels[179:]
X_train, X_test, y_train, y_test = train_test_split(data, labels, test_size=0.25, random_state=42)

# 创建数据加载器
train_loader = DataLoader(TensorDataset(X_train, y_train), batch_size=2, shuffle=True)
test_loader = DataLoader(TensorDataset(X_test, y_test), batch_size=2, shuffle=False)


# 定义模型
class Net(nn.Module):
    def __init__(self):
        super(Net, self).__init__()
        self.fc1 = nn.Linear(9, 7)
        self.fc2 = nn.Linear(7, 1)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.sigmoid(self.fc2(x))
        return x


model = Net()
criterion = nn.BCELoss()
optimizer = optim.Adam(model.parameters(), lr=0.01)

# 训练模型
model.train()
for epoch in range(100):
    for inputs, targets in train_loader:
        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs.squeeze(), targets)
        loss.backward()
        optimizer.step()

# 测试模型
model.eval()
with torch.no_grad():
    predictions = model(X_test)
    # Assuming binary classification with a threshold of 0.5
    predicted_labels = (predictions.squeeze() > 0.5).float()
    accuracy = (predicted_labels == y_test).float().mean()
    print(f'Accuracy: {accuracy.item()}')


# 输出模型结构
print(model)
